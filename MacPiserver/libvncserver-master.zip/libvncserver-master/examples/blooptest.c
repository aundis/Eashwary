#define BACKGROUND_LOOP_TEST
#include "example.c"
