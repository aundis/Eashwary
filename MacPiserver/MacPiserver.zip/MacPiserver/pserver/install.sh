cd ../libimobiledevice-1.1.7/
make clean
make
cd ../pserver/
make clean
make
