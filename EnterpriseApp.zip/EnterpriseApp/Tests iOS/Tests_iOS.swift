//
//  Tests_iOS.swift
//  Tests iOS
//
//  Created by Eashwary on 30/05/22.
//

import XCTest

class Tests_iOS: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // UI tests must launch the application that they test.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        
        let app = XCUIApplication(bundleIdentifier: "com.apple.Preferences")
        app.launch()
        app.terminate()

        let settingsApp = XCUIApplication(bundleIdentifier: "com.apple.Preferences")
        settingsApp.launch()
        
        let status = settingsApp.tables.cells.staticTexts["General"].exists;
        
        if(status == true){
            settingsApp.tables.cells.staticTexts["General"].tap();
            if(settingsApp.tables.cells.staticTexts["Device Management"].exists)
            {
                settingsApp.tables.cells.staticTexts["Device Management"].tap();
            }
            else if settingsApp.tables.cells.staticTexts["VPN & Device Management"].exists
            {
                settingsApp.tables.cells.staticTexts["VPN & Device Management"].tap();
            }
            if(settingsApp.tables.cells.staticTexts["Not Trusted"].exists)
            {
                settingsApp.tables.cells.staticTexts["Not Trusted"].tap();
                let predicate = NSPredicate(format: "label CONTAINS[c] %@", "Trust ")
                if(settingsApp.staticTexts.containing(predicate).firstMatch.exists)
                {
                    settingsApp.staticTexts.containing(predicate).firstMatch.tap()
                    if(settingsApp.alerts.buttons["Trust"].exists)
                    {
                        settingsApp.alerts.buttons["Trust"].tap();
                        
                    }
                    else if(settingsApp.popUpButtons["Trust"].exists)
                    {
                        settingsApp.popUpButtons["Trust"].tap();
                        
                    }
                }
            }
            
        }
        app.terminate()
        
    }

    func testLaunchPerformance() throws {
        if #available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 7.0, *) {
            // This measures how long it takes to launch your application.
           // measure(metrics: [XCTApplicationLaunchMetric()]) {
               // XCUIApplication().launch()
           // }
        }
    }
}

