//
//  EnterpriseAppApp.swift
//  Shared
//
//  Created by Eashwary on 02/06/22.
//

import SwiftUI

@main
struct EnterpriseAppApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
