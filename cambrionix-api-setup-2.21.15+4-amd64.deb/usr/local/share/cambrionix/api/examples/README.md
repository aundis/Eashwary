# Cambrionix API Examples

There are various scripting examples in these sub-folders of how to access the
Cambrionix API.

## nodejs

An example Node.JS project showing a simple request/callback method for calling
the API. This approach uses unique ids on each request to match up the
originating request callbacks.

## python/asyncio

A new example script showing asyncronous API access using the Python3 asyncio
module. This method uses asyncronous Tasks which allows for async functions to
by used to process the values as they come without blocking the application.

## python/python-old-examples

Kept for historical reasons. These were the old example Python2/3 scripts that
were bundled prior to API version 2.20. They are inferior to the new script
because these are based on a call & wait-for-reply approach, so would block
while a request was being handled.

## C#

A C# project showing asynchronous access to the API to fetch basic information.

## VB.Net

A VB.NET project showing asynchronous access to the API to fetch basic
information. Note that this is identical in functionality to the C# example that
was converted to VB by a conversion tool.
