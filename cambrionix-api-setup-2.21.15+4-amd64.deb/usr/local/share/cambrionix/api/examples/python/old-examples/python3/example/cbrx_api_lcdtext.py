#!/usr/bin/env python3
#
# Cambrionix Ltd - 2021
# Title: Python 3 - Change LCD text
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

import sys
import random
from cbrxapi import cbrxapi
import jsonrpc

result = cbrxapi.cbrx_discover("local")
if result==False:
    print("No Cambrionix unit found.")
    sys.exit(0)


unitId = result[0]
handle = cbrxapi.cbrx_connection_open(unitId)
try:
    cbrxapi.cbrx_connection_set(handle, "RemoteControl", True)
except jsonrpc.RPCFault:
    print("Unit does not accept RemoteControl")
    cbrxapi.cbrx_connection_close(handle)
    sys.exit(1)

cbrxapi.cbrx_connection_set(handle, "ClearLCD", True)
cbrxapi.cbrx_connection_set(handle, "LCDText.0.0", "Hello world!")


cbrxapi.cbrx_connection_close(handle)
