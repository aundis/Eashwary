#!/usr/bin/env python2.7
#
# Cambrionix Ltd - 2021
# Title: Python 2.7 - Set security mode
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

import sys
import random
import jsonrpc

CBRXAPI_LISTENINGPORT = 43424

cbrxapi = jsonrpc.ServerProxy(
    jsonrpc.JsonRpc20(),
    jsonrpc.TransportTcpIp(addr=("localhost", CBRXAPI_LISTENINGPORT),
    timeout=200.0)
    )

result = cbrxapi.cbrx_discover("local")
if result==False:
    print("No Cambrionix unit found.")
    sys.exit(0)

unitId = result[0]
handle = cbrxapi.cbrx_connection_open(unitId)
try:
    cbrxapi.cbrx_connection_set(handle, "RemoteControl", True)
except jsonrpc.RPCFault:
    print("Unit does not accept RemoteControl")
    cbrxapi.cbrx_connection_close(handle)
    sys.exit(1)

cbrxapi.cbrx_connection_set(handle, "ClearLCD", True)
cbrxapi.cbrx_connection_set(handle, "SecurityArmed", True)
cbrxapi.cbrx_connection_set(handle, "LCDText.0.0", "ALARM ENABLED")

buttonPushed = False
while not buttonPushed:
    value = cbrxapi.cbrx_connection_get(handle, "Key.1")
    # print value,
    if value == 1:
        buttonPushed = True
        
cbrxapi.cbrx_connection_set(handle, "SecurityArmed", False)

cbrxapi.cbrx_connection_set(handle, "Beep", 500)
cbrxapi.cbrx_connection_set(handle, "Beep", 500)
cbrxapi.cbrx_connection_set(handle, "Beep", 500)

cbrxapi.cbrx_connection_set(handle, "LCDText.0.0", "ALARM DISABLED")

cbrxapi.cbrx_connection_close(handle)
