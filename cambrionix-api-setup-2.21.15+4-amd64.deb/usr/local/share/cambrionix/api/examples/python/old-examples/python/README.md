# Cambrionix API

**Deprecated and unmaintained. Please use the new examples in the ../../python
folder**

This is some example Python code and supporting modules for accessing the
Cambrionix API.

You will need Python installed on your computer For Windows this can be
downloaded from the [Python website](https://www.python.org/downloads/). Linux
and macOS users will almost certainly have Python already installed.

Cambrionix have tested with Python 2.7 and Python 3.6 onwards. Modern version of
python are bundled with setup-tools and pip, so there should be no further
requirements.

The installation program should have done all of this for you unless you elected
not to, in which case you just need to run **`python setup.py install`**.

In the examples directory are various exmaple scripts, the simplest of which is
cbrx_api_quickstart.py which you can use as a confidence test that everything is
installed correctly. If you have a Cambrionix universal charger attached to the
local machine on executing **`python cbrx_api_quickstart.py`** you should see it
report the number of ports on the Cambrionix charger.

The included Python scripts are just a simple example of one possible way to
talk to the API. Any language is supported and you simply need to open a TCP
connection to localhost:43424 and use standard JSON-RPC to communicate. Please
see the API reference for further details on this.
