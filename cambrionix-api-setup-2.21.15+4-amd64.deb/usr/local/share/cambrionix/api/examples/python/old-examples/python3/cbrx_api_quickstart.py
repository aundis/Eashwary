#!/usr/bin/env python3

# Cambrionix Ltd - 2021
# Title: Python 3 - Quick Start
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

import sys
from cbrxapi import cbrxapi

print("Querying API Version...")
try:
    result = cbrxapi.cbrx_apiversion()
except Exception as e:
    print("Could not comminicate with API : " + str(e))
    result = None

if result:
    print("API Version %d.%d" % (result[0], result[1]))

print("Discovering local devices..")
result = cbrxapi.cbrx_discover("local")
if not result or len(result) == 0:
    print("No Cambrionix unit found.")
    sys.exit(0)

print("Discovered %d units" % len(result))

for unitId in result:
    serialPort = cbrxapi.cbrx_discover_id_to_os_reference(unitId)

    try:
        handle = cbrxapi.cbrx_connection_open(unitId)
    except Exception as e:
        print("Could not open conneciton to %s : %s" % (unitId, str(e)))
        handle = None

    if handle:
        hardware = cbrxapi.cbrx_connection_get(handle, "Hardware")
        nrOfPorts = cbrxapi.cbrx_connection_get(handle, "nrOfPorts")

        cbrxapi.cbrx_connection_close(handle)

        print("* %s on %s has %d ports" % (hardware, serialPort, nrOfPorts))
