#!/usr/bin/env python3
#
# Cambrionix Ltd - 2021
# Title: Python 3 - Flash LEDs 1
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

import sys
import random
from cbrxapi import cbrxapi
import jsonrpc

result = cbrxapi.cbrx_discover("local")
if result == False:
    print("No Cambrionix unit found.")
    sys.exit(0)


unitId = result[0]
handle = cbrxapi.cbrx_connection_open(unitId)
nrOfPorts = cbrxapi.cbrx_connection_get(handle, "nrOfPorts")
print("The Cambrionix unit " + unitId + " has " + str(nrOfPorts) + " ports.")
try:
    cbrxapi.cbrx_connection_set(handle, "RemoteControl", True)
except jsonrpc.RPCFault:
    print("Unit does not accept RemoteControl")
    cbrxapi.cbrx_connection_close(handle)
    sys.exit(1)

handle = cbrxapi.cbrx_connection_open(unitId)

for j in range(1, 20000):
    print(j),
    print(" "),
    if j % 10 == 0:
        print('')

    try:
        cbrxapi.cbrx_connection_set(handle, "LCDText.0.0", "Red")
        cbrxapi.cbrx_connection_set(handle, "LCDText.1.0", str(j) + " ")
    except jsonrpc.RPCTransportError:
        print("Hic.")
        pass
    
    for i in range(1, nrOfPorts):
        try:
            cbrxapi.cbrx_connection_set(handle, "Port." + str(i) + ".led1", 255 * (j % 2))

        except jsonrpc.RPCTransportError:
            print("Hic.")
            pass
        
   
cbrxapi.cbrx_connection_close(handle)
