#!/usr/bin/env python3.4

# Cambrionix Ltd - 2021
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

from jsonrpc_websocket import Server

class CambrionixApiAsyncImpl(Server):

    def __init__(self):
        super().__init__('ws://localhost:43424')
        pass

    async def close(self):
        await super().close()
        await self._session.close()

# Create instance of CambrionixApiAsyncImpl and trigger WebSocket connection.
# This is an asynchronous function, so call with await.
async def CambrionixApiAsync():
    server = CambrionixApiAsyncImpl()

    try:
        await server.ws_connect()
    except Exception as e:
        print("Failed to connect to API ", e)

    return server
