#!/usr/bin/env python2.7
#
# Cambrionix Ltd - 2021
# Title: Python 2.7 - Port mode switching
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

import sys
from cbrxapi import cbrxapi 

result = cbrxapi.cbrx_discover("local")
if result==False:
    print("No Cambrionix unit found.")
    sys.exit(0)

unitId = result[0]
handle = cbrxapi.cbrx_connection_open(unitId)

# set port 1 off
print("Setting port 1 to off")
result = cbrxapi.cbrx_connection_set(handle, "Port.1.mode", "o")

# set port 1 to charge mode
print("Setting port 1 to charge mode")
result = cbrxapi.cbrx_connection_set(handle, "Port.1.mode", "c")

# set port 1 to sync mode
print("Setting port 1 to sync mode")
result = cbrxapi.cbrx_connection_set(handle, "Port.1.mode", "s")

cbrxapi.cbrx_connection_close(handle)
