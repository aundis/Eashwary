#!/usr/bin/env python3
#
# Cambrionix Ltd - 2021
# Title: Python 3 - Find devices by name or VID/PID
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

import sys
from cbrxapi import cbrxapi
from HexPrettyPrinter import HexPrettyPrinter
import argparse

parser = argparse.ArgumentParser(description = "Returns all devices connected to any Cambrionix unit matching the specified limits. When specifying vid, both vid and pid may be used together.")
parser.add_argument("--vid", type=str, help="Match vendor id.")
parser.add_argument("--pid", type=str, help="Match product id.")
parser.add_argument("--name", type=str, help="Matching the regex pattern of manufacterer name and product name.")
parser.add_argument("--oneline", action='store_true', help="Only show brief information of each result.")
args = parser.parse_args()

if args != None:

    if args.vid:
        if args.vid[:2] == "0x":
            vid = int(args.vid[2:], 16)
        else:
            vid = int(args.vid, 10)

        if args.pid:
            if args.pid[:2] == "0x":
                pid = int(args.pid[2:], 16)
            else:
                pid = int(args.pid, 10)

            found = cbrxapi.cbrx_find(vid, pid)        # Microchip Technology Inc. Joystick Demo
        else:
            found = cbrxapi.cbrx_find(vid)

    elif args.name:
        # When finding by name, you can use a regex search.
        # The match is performed against: "<manufacturer> <description> <serial-number>"

        found = cbrxapi.cbrx_find(args.name)

    else:
        parser.print_help()
        sys.exit(0)

    if found != None:
        if args.oneline:
            for serial in found:
                details = found[serial]
                print("%s on port %d of %s (%s)" % (serial, details['HostPort'], details['HostDescription'], details['HostDevice']))

        else:
            pp = HexPrettyPrinter(width=160)
            pp.pprint(found)
