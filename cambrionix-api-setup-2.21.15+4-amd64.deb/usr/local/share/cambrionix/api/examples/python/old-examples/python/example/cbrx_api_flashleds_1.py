#!/usr/bin/env python2.7
#
# Cambrionix Ltd - 2021
# Title: Python 2.7 - Flash Leds 1
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

import sys
import random
from cbrxapi import cbrxapi
import jsonrpc

result = cbrxapi.cbrx_discover("local")
if result==False:
    print("No Cambrionix unit found.")
    sys.exit(0)


unitId = result[0]
handle = cbrxapi.cbrx_connection_open(unitId)
nrOfPorts = cbrxapi.cbrx_connection_get(handle, "nrOfPorts")
print("The Cambrionix unit " + unitId + " has " + str(nrOfPorts) + " ports.")
try:
    cbrxapi.cbrx_connection_set(handle, "RemoteControl", True)
except jsonrpc.RPCFault:
    print("Unit does not accept RemoteControl")
    cbrxapi.cbrx_connection_close(handle)
    sys.exit(1)

j = 1
while j < 200000:
    print(j,)
    print(" ",)
    if j % 10 == 0:
        print

    try:
        cbrxapi.cbrx_connection_set(handle, "LCDText.0.0", "Red")
        cbrxapi.cbrx_connection_set(handle, "LCDText.1.0", str(j) + " ")
    except jsonrpc.RPCTransportError:
        print("Hic.")
        pass
    
    i = 1
    while (i <= nrOfPorts):
        try:
            cbrxapi.cbrx_connection_set(handle, "Port." + i + ".led1", 255*(j % 2))
        except jsonrpc.RPCTransportError:
            print("Hic.")
            pass
        
        i += 1
    
    j += 1
    
cbrxapi.cbrx_connection_close(handle)
