#!/usr/bin/env python3.4

# Cambrionix Ltd - 2021
# Title: Python 3.4 - Asynchronous IO example
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

# This example uses the Python 3 asyncio library to provide asynchronous access
# to the API. This is a modern approach that allows non-blocking API requests
# which frees up your program to do other things instead of blocking and
# waiting for replies.

# Note that because all of these requests return asynchronous Task instances,
# you need to 'await' the result from each. See Python 3 documentation for usage
# of the 'await' keyword: https://docs.python.org/3/library/asyncio-task.html

# Aside from 'await'ing the results in this example, the usage is nearly
# identical to the older synchronous example scripts. The downside of the old
# scripts is having to wait for the previous result before the program continues
# and you can make a new request.

# The asyncio library (a core part of Python 3's coroutine functionality) has a
# not-insignificant load time. But, if you're already using asyncio, then it of
# course won't have a detrimental impact to your existing code. That said, I
# still feel the overhead is worth the benefits of this modern programming
# approach.
import asyncio

# This version of the API instance connection uses an Asynchrous JSON-RPC
# library found here: https://github.com/emlove/jsonrpc-websocket/. This
# automates the connection to the API via a WebSocket to allow asynchronous
# communication. It also automates the conversion of method calls (i.e.
# cbrxapi.cbrx_discover) to JSON-RPC packets with "cbrx_discover" as the method
# name and the remaining parameters to the "params" field, in either named or
# list style. For those of you familiar with the old examples, very little has
# changed except the necessary addition of the 'await' keyword.
from CambrionixApiAsync import *

# A syntax error here would mean you're trying to run this with Python 2 which
# does not have the async keyword.
async def DumpHubInfo(cbrxapi: CambrionixApiAsync, hubSerialNumber: str):

    # cbrx_connection_open is used to make a connection to the
    # requested hub so that additional information can be retreived.
    # See: https://www.cambrionix.com/Downloads/API/Cambrionix%20API%20Reference.html#cbrx_connection_open
    handle = await cbrxapi.cbrx_connection_open(hubSerialNumber)

    # cbrx_connection_get is used to retreive information from the handle that
    # we connected to the hub with
    # See: https://www.cambrionix.com/Downloads/API/Cambrionix%20API%20Reference.html#cbrx_connection_get

    # PortsInfo requests the entire information stored for all ports on the hub
    # See: https://www.cambrionix.com/Downloads/API/Cambrionix%20API%20Reference.html#get-portsinfo

    # Note that we're storing the requests here, rather than the resulting
    # values. We can make a bunch of requests like this which lets the API deal
    # with it and reply while this code continues to run
    task_PortsInfo = cbrxapi.cbrx_connection_get(handle, "PortsInfo")

    # Request the number of ports the hub has
    task_nrOfPorts = cbrxapi.cbrx_connection_get(handle, "nrOfPorts")
    # Request the type of hub
    task_Hardware = cbrxapi.cbrx_connection_get(handle, "Hardware")

    # Using await here will wait for the response from the API This will NOT
    # block the operation of your program as its running on its own thread and
    # does nothing while until the reply is read.
    print("%s is a %s with %d ports" % (hubSerialNumber, await task_Hardware, await task_nrOfPorts))

    # The ordering does not matter. We can expect the 2 other requests to
    # complete quickly because they only return a single result, whereas the
    # PortsInfo returns a fairly large dictionary of data.
    #
    # Additionally, the API itself processes these requests in their own
    # threads, so the replies can come in any order.
    PortsInfo = await task_PortsInfo

    for PortInfo in PortsInfo.values():
        if "A" in PortInfo['Flags']:
            if PortInfo['Description']:
                deviceName = PortInfo['Manufacturer'] + " " + PortInfo['Description']
            else:
                # Devices such as iPhones may not show up on the USB Tree if they are locked
                deviceName = "Unknown Device"

            print("%s port %d has a %s connected drawing %d milliamps" % (hubSerialNumber, PortInfo['Port'], deviceName, PortInfo['Current_mA']))

async def routine():
    # Create a single instance of an API connection. You can either do this or
    # use many separate connections to the API. It makes little difference in
    # the long run since the API deals with all requests in a threaded manner
    # anyway.
    try:
        cbrxapi = await CambrionixApiAsync()

        # Get API version as a quick way to check API is running
        apiVersion = await cbrxapi.cbrx_apiversion()
        print("API Version: %d.%d" % (apiVersion[0], apiVersion[1]))

        # Discover all of the connected Cambrionix Hubs and returns this as a
        # list of hub serial numbers
        localHubs = await cbrxapi.cbrx_discover("local")

        print("Discovered %d Cambrionix hub(s)" % len(localHubs))

        # DumpHubInfo is asynchronous, so keep a record of each task, 1 per hub,
        # so we can later wait for each task to complete. Each call to an async
        # function will run it on its own coroutine worker thread, so they can
        # do the work at the same time.
        listOfJobs = []
        for hubSerialNumber in localHubs:
            # ensure_future allows multiple tasks to run concurrently
            listOfJobs.append(asyncio.ensure_future(DumpHubInfo(cbrxapi, hubSerialNumber)))

        # Wait for the jobs to finish. This way we don't wait for one before
        # another starts, and can instead let each job run in its own time. This
        # may cause overlapping prints because the job can run simultaniously
        # for all hubs. But this is really the point of this demo, to show the
        # benefits of asynchronous IO. So instead of the old examples that would
        # wait for the reply of a request before moving on, we can do multiple
        # things at the same time.
        for entry in listOfJobs:
            await entry

    except Exception as e:
        print(e)

    finally:
        await cbrxapi.close()

asyncio.get_event_loop().run_until_complete(routine())
