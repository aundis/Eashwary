#!/usr/bin/env python3
#
# Cambrionix Ltd - 2021
# Title: Python 3 - USBTree dump example
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

import sys
from cbrxapi import cbrxapi
from HexPrettyPrinter import HexPrettyPrinter

usbTree = cbrxapi.cbrx_get_usbtree()

pp = HexPrettyPrinter(width=160)
pp.pprint(usbTree)
