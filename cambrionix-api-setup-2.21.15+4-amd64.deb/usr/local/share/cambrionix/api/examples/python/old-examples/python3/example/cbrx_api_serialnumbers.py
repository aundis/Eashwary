#!/usr/bin/env python3
#
# Cambrionix Ltd - 2021
# Title: Python 3 - Dump serial numbers
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

import sys
from cbrxapi import cbrxapi
import jsonrpc

def signal_handler(signal, frame):
    print ("Closing connection")
    cbrxapi.cbrx_connection_close(handle)
    sys.exit(0)
try:
    result = cbrxapi.cbrx_discover("local")
except jsonrpc.RPCTransportError as err:
    print ('')
    print ("Failed to communicate with API - ")
    print (err.args[0])
    sys.exit(-1)
if not result:
    print ("No Cambrionix unit found.")
    sys.exit(0)

try:
    for unitId in result:
        print("Device: %s" % unitId)
        handle = cbrxapi.cbrx_connection_open(unitId)

        nrOfPorts = cbrxapi.cbrx_connection_get(handle, "nrOfPorts")
        portsinfo = cbrxapi.cbrx_connection_get(handle, "PortsInfo")

        for loop in range(1, nrOfPorts):
            portinfo = portsinfo['Port.' + str(loop)]
            serialnumber = portinfo['SerialNumber']
            if serialnumber is not "":
                print("Port %d = %s" % (loop, serialnumber))
            loop = loop + 1
        cbrxapi.cbrx_connection_close(handle)

except KeyboardInterrupt:
    print ('')
    print ("Tidying up")
    #cbrxapi.cbrx_connection_set(handle, "RemoteControl", False)
    cbrxapi.cbrx_connection_close(handle)
    sys.exit(0)
except jsonrpc.RPCTransportError as err:
    print ('')
    print ("Failed to communicate with API - ")
    print (err.args[0])
    sys.exit(-1)
except jsonrpc.RPCFault as err:
    print ('')
    print ("Error communicating with API - RPCFault " + str(err.error_code) + " " + err.error_message)
    cbrxapi.cbrx_connection_close(handle)
    sys.exit(-1)
