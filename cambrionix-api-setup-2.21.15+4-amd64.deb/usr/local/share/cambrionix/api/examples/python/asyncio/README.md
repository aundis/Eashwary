# Cambrionix API Asynchronous Python Example

This new example is designed for **Python 3.4+** and uses more modern
asynchronous IO to communicate with the API. Essentially, this version of the
Python examples returns a promise, rather than the value itself.

This allows simultaneous requests to run and replies to come in the order
they're processed by the API. Therefor it is not necessary to rely on the order
of the replies, but instead simply `await` the response to the request.

## Pre-requisites

As well as Python 3.4, you just need the jsonrpc-websocket module:

```
pip3 install jsonrpc-websocket
```

## Usage

As with the deprecated examples, the jsonrpc-websocket module automatically
converts things like:

```python
cbrxapi.cbrx_connection_open("DJ000102")
```

Into something suitable for a json-rpc packet that is sent to the API:

```json
{
    "id": 0,
    "jsonrpc": "2.0",
    "method": "cbrx_connection_open",
    "params": ["DJ000102"]
}
```

Replies are automatically converted back from JSON into a Python dictionary, or
list or value as appropriate.

### What's changed from the old examples

For those of you that have used the examples we previously supplied (still
provided in the examples/python/old-examples folder), you will find the syntax
is nearly identical barring the additional `await` to get the result from the
promise:

```python
# Asynchronous method:
handle = await cbrxapi.cbrx_connection_open("DJ000102")

# Equivelant example in deprecated examples:
handle = cbrxapi.cbrx_connection_open("DJ000102")
```

Of course, you don't need to immediately `await` a result. You can store the
Task instance instead that is returned and await the reply when you actually
need it. See the example usage in cbrx_api_quickstart.py for details on how this
can be accomplished.
