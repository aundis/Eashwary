#!/usr/bin/env python3
#
# Cambrionix Ltd - 2021
# Title: Python 3 - Flash LEDs
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

import signal
import sys
from cbrxapi import cbrxapi 
import jsonrpc

handle = 0

def signal_handler(signal, frame):
    print("Closing connection")
    cbrxapi.cbrx_connection_close(handle)
    sys.exit(0)
    
result = cbrxapi.cbrx_discover("local")
if result == False or len(result) == 0:
    print("No Cambrionix unit found.")
    sys.exit(0)

unitId = result[0]
handle = cbrxapi.cbrx_connection_open(unitId)
nrOfPorts = cbrxapi.cbrx_connection_get(handle, "nrOfPorts")
print("The Cambrionix unit " + unitId + " has " + str(nrOfPorts) + " ports.")
try:
    cbrxapi.cbrx_connection_set(handle, "RemoteControl", True)
except jsonrpc.RPCFault:
    print("Unit does not accept RemoteControl")
    cbrxapi.cbrx_connection_close(handle)
    sys.exit(1)

try:
    for j in range(0, 20000):
        print(j)

        try:
            cbrxapi.cbrx_connection_set(handle, "LCDText.0.0", "Blinking... " + str(j))
        except:
            pass
            
        for i in range(1, nrOfPorts):
            value = 255 * (j % 2)
            value = value | (value << 8) | (value << 16)
            cbrxapi.cbrx_connection_set(handle, "Port." + str(i) + ".leds", value)
        
    cbrxapi.cbrx_connection_close(handle)

except KeyboardInterrupt:
    print('')
    print("Tidying up")
    cbrxapi.cbrx_connection_close(handle)
    sys.exit(0)
    
