#!/usr/bin/env python3
#
# Cambrionix Ltd - 2021
#
# This is sample software provided to you without implied warranty of any sort.
# You are free to use and adapt this for your own use.

# Most of the numbers we display make more sense in hex
from pprint import PrettyPrinter

class HexPrettyPrinter(PrettyPrinter):
    def format(self, object, context, maxlevels, level):
        repr, readable, recursive = PrettyPrinter.format(self, object, context, maxlevels, level)
        if isinstance(object, int):
            if object > 16:
                return "0x{0:04x}".format(object), readable, recursive
        return repr, readable, recursive
