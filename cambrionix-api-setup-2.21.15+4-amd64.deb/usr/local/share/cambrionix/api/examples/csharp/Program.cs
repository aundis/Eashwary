using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

#pragma warning disable IDE1006 // Naming Styles

namespace cbrx_csharp_example
{
    public interface NotificationHandler
    {
        void OnNotificationReceived(string method, object data);
    }

    public class CambrionixApi
    {
        private const string ApiConnectionAddress = "localhost";
        // The port number for the remote device.  
        private const int ApiConnectionPort = 43424;
        private Socket m_socket;
        private bool m_connected = false;
        private NotificationHandler m_notifacationHandler;

        // Size of receive buffer.  
        private const int BufferSize = 10240;
        // Receive buffer.  
        private readonly byte[] m_buffer = new byte[BufferSize];
        // Received data string.  
        private readonly StringBuilder m_stringBuilder = new StringBuilder();
        public bool IsConnected { get { return m_connected; } }

        public struct Response
        {
            public int m_id;
            public bool m_error;
            public JsonErrorInfo m_errorInfo;
            public string m_method;
            public object m_result;
            public JsonReply m_completeJsonResult;
        }

        // Storage for a sent request
        private struct Packet
        {
            public int m_id;
            internal TaskCompletionSource<Response> m_task;
        }

        // Next unique ID for this connection
        private int m_nextID = 0;
        // Pending packets expecting replies
        private readonly Dictionary<int, Packet> m_pending = new Dictionary<int, Packet>();

        public CambrionixApi(NotificationHandler notifacationHandler = null)
        {
            m_notifacationHandler = notifacationHandler;

            StartClient();
        }

        ~CambrionixApi()
        {
            StopClient();
        }

        private void StartClient()
        {
            // Connect to a remote device.  
            try
            {
                // Establish the remote endpoint for the socket. The API will must running on the local machine
                IPHostEntry ipHostInfo = Dns.GetHostEntry(ApiConnectionAddress);
                IPAddress ipAddress = ipHostInfo.AddressList[1];                // Get IPv4 address
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, ApiConnectionPort);

                // Create a TCP/IP socket.  
                m_socket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                // Connect to the remote endpoint.  
                m_socket.Connect(remoteEP);

                if (m_socket.Connected)
                {
                    m_connected = true;
                    Receive();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        private void StopClient()
        {
            m_socket.Close();
        }

        private void Receive()
        {
            try
            {
                // Begin receiving the data from the remote device.  
                m_socket.BeginReceive(m_buffer, 0, BufferSize, 0, new AsyncCallback(ReceiveCallback), this);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        private int ParseJsonInputStream(String buffer)
        {
            char inQuotes = '\0';
            bool escaping = false;
            int commandStart = 0;
            int expired = 0;
            String stack = "";
            int ptr = 0;

            while (ptr < buffer.Length)
            {
                char c = buffer[ptr];

                if (escaping)
                {
                    escaping = false;
                    continue;
                }

                if (inQuotes == '\0')
                {
                    if (c == '{' || c == '[')
                    {
                        if (stack.Length == 0)
                        {
                            commandStart = ptr;
                        }
                        stack += (c == '{' ? '}' : ']');
                    }
                    else if (c == '}' || c == ']')
                    {
                        if (stack[stack.Length - 1] == c)
                        {
                            stack = stack.Remove(stack.Length - 1);

                            if (stack.Length == 0)
                            {
                                expired = ptr + 1;

                                String packet = buffer.Substring(commandStart, expired - commandStart);
                                OnJsonReceived(packet);

                                commandStart = expired;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Parse error");
                            return buffer.Length;
                        }
                    }
                    else if (c == '"')
                    {
                        //Ignore anything in a string, in case there are braces
                        inQuotes = '"';
                    }
                    else if (c == '\'')
                    {
                        inQuotes = '\'';
                    }
                    else if (c == '\\')
                    {
                        escaping = true;
                    }
                }
                else if (c == inQuotes)
                {
                    inQuotes = '\0';
                }

                ++ptr;
            }

            return expired;
        }

        private void ReceiveCallback(IAsyncResult ar)
        {
            try
            {
                // Read data from the remote device.  
                int bytesRead = m_socket.EndReceive(ar);

                if (bytesRead > 0)
                {
                    // There might be more data, so store the data received so far.  
                    m_stringBuilder.Append(Encoding.ASCII.GetString(m_buffer, 0, bytesRead));

                    if (ar.IsCompleted)
                    {
                        string response = m_stringBuilder.ToString();
                        m_stringBuilder.Clear();

                        // Console.WriteLine("IN: {0}", response);

                        // Can get multiple replies in a single response, so break them up into individually valid JSON chunk
                        // and process them each separately
                        ParseJsonInputStream(response);
                    }
                }

                Receive();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        private void Send(String data)
        {
            // Convert the string data to byte data using ASCII encoding.  
            byte[] byteData = Encoding.ASCII.GetBytes(data);

            m_socket.Send(byteData);
        }

        public struct JsonErrorInfo
        {
            public int code { get; set; }
            public string message { get; set; }
        }

        public struct JsonReply
        {
            public int id { get; set; }                     // The ID that was given in the request packet. Not present in notifications
            public string jsonrpc { get; set; }             // Always "2.0"
            public string method { get; set; }              // Only included with notifications
            public object result { get; set; }              // Only present in case of success
            public JsonErrorInfo error { get; set; }        // Only present in case of errors
        }

        bool HasValue(dynamic d, string key)
        {
            try
            {
                dynamic test = d[key];
                return test != null;
            }
            catch
            {
                return false;
            }
        }

        private void OnJsonReceived(string json)
        {
            // First parse to check type of packet
            dynamic test = JObject.Parse(json);

            if (!HasValue(test, "id"))
            {
                // Notifications don't have an id field. They can be sent at any
                // time by the API after subscribing to specified events. We're
                // not subscribing to any notifications in this example You can
                // find information about notifications in the API reference.
                // https://www.cambrionix.com/Downloads/API/Cambrionix%20API%20Reference.html#cbrx_notifications

                if (m_notifacationHandler != null)
                {
                    string method = null;
                    object @params = null;
                    try
                    {
                        method = (string)test["method"];
                        @params = (object)test["params"];
                    }
                    catch
                    {
                        //ignore
                    }

                    if (method != null && @params != null)
                    {
                        m_notifacationHandler.OnNotificationReceived(method, @params);
                    }
                }
            }
            else
            {
                JsonReply result = JsonConvert.DeserializeObject<JsonReply>(json);

                // Make sure we were expecting this result

                if (m_pending.ContainsKey(result.id))
                {
                    Packet pending = m_pending[result.id];

                    Response reply = new Response
                    {
                        m_completeJsonResult = result,
                        m_result = result.result,
                        m_id = result.id,
                        m_errorInfo = result.error,
                        m_error = result.error.code != 0
                    };

                    if (reply.m_error)
                    {
                        Console.Error.WriteLine("Error received from API : {0} {1}", result.error.code, result.error.message);
                    }

                    // Fulfil the promise
                    pending.m_task.SetResult(reply);

                    m_pending.Remove(result.id);
                }
            }

            //Console.WriteLine(result.ToString());
        }

        /**
         * Make a request to the API. The optional parameters can be either an
         * array<object> or a Dictionary<string,object> We use incrementing ids
         * for the requests because the API is asynchronous and the replies can
         * come back in any order. So we keep a record of API requests and use
         * the id to find the original request and complete the Task.
         */
        public TaskCompletionSource<Response> MakeRequest(string method, object parameters = null)
        {
            try
            {
                Packet packet;
                packet.m_id = Interlocked.Increment(ref m_nextID);
                packet.m_task = new TaskCompletionSource<Response>();

                Dictionary<string, object> json = new Dictionary<string, object>();
                json["id"] = packet.m_id;
                json["jsonrpc"] = "2.0";
                json["method"] = method;

                if (parameters != null)
                {
                    json["params"] = parameters;
                }

                var serialisedJson = JsonConvert.SerializeObject(json);

                Send(serialisedJson);

                // Console.WriteLine("OUT: {0}", serialisedJson);

                m_pending[packet.m_id] = packet;

                return packet.m_task;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            return null;
        }
    }

    class Program
    {
        private static CambrionixApi api;

        static async void GetApiVersion()
        {
            var future = api.MakeRequest("cbrx_apiversion");                        // cbrx_apiversion()

            var result = await future.Task;
            if (result.m_error)
            {
                Console.WriteLine("Could not get API Version: " + result.m_error.ToString());
            }
            else if (result.m_result is JArray)
            {
                JArray version = result.m_result as JArray;

                // Result will contain an array of integers representing the version: [2.19]
                Console.WriteLine("API Version: " + string.Join(".", version));
            }
        }

        static async void GetDiscoveredHubs()
        {
            try
            {
                var future = api.MakeRequest("cbrx_discover", new[] { "local" });

                var resultDiscover = await future.Task;
                if (!resultDiscover.m_error)
                {
                    // Result will contain an array of strings which are the hub serial numbers

                    if (resultDiscover.m_result is JArray)
                    {
                        JArray result = resultDiscover.m_result as JArray;

                        Console.WriteLine("Found the following Cambrionix hubs: " + string.Join(", ", result));

                        foreach (var entry in result)
                        {
                            string hubSerialNumber = entry.Value<string>();
                            GetHubInformation(hubSerialNumber);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        static async void GetHubInformation(string hubSerialNumber)
        {
            try
            {
                // cbrx_connection_open is used to make a connection to the
                // requested hub so that additional information can be retreived.
                // See: https://www.cambrionix.com/Downloads/API/Cambrionix%20API%20Reference.html#cbrx_connection_open
                var futureOpen = api.MakeRequest("cbrx_connection_open", new[] { hubSerialNumber });

                var resultOpen = await futureOpen.Task;
                if (!resultOpen.m_error)
                {
                    // Validate the returned handle is a number
                    // Failing to open can return false
                    if (resultOpen.m_result is long)
                    {
                        long handle = (long)resultOpen.m_result;

                        // cbrx_connection_get is used to retreive information from the handle that we connected to the hub with
                        // See: https://www.cambrionix.com/Downloads/API/Cambrionix%20API%20Reference.html#cbrx_connection_get

                        // PortsInfo requests the entire information stored for all ports on the hub
                        // See: https://www.cambrionix.com/Downloads/API/Cambrionix%20API%20Reference.html#get-portsinfo
                        var futureGetPortsInfo = api.MakeRequest("cbrx_connection_get", new object[] { handle, "PortsInfo" });

                        var resultGetPortsInfo = await futureGetPortsInfo.Task;
                        if (!resultGetPortsInfo.m_error)
                        {
                            if (resultGetPortsInfo.m_result is JObject)
                            {
                                JObject discovery = resultGetPortsInfo.m_result as JObject;
                                int numberOfPorts = discovery.Count;

                                Console.WriteLine("The hub {0} has {1} ports", hubSerialNumber, numberOfPorts);

                                foreach (var entry in discovery)
                                {
                                    var values = entry.Value;

                                    // See the API reference for meanings of the flags
                                    // https://www.cambrionix.com/Downloads/API/Cambrionix%20API%20Reference.html#get-port.n.flags
                                    bool attached = values.Value<string>("Flags").Contains("A");

                                    if (attached)
                                    {
                                        int portNumber = values.Value<int>("Port");
                                        var manufacturer = values.Value<string>("Manufacturer");
                                        var description = values.Value<string>("Description");
                                        var currentMA = values.Value<int>("Current_mA");

                                        Console.WriteLine("{0}: Port {1} has a {2} {3} which is drawing {4} milliamps", hubSerialNumber, portNumber, manufacturer, description, currentMA);
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Could not connect to the hub : {0} {1} ", resultOpen.m_errorInfo.code, resultOpen.m_errorInfo.message);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        static void SetupMyNotifications()
        {
            api.MakeRequest("cbrx_notifications", new[] { "usb-device-attached", "usb-device-detached" });

            // Other notifications are detailed in the API Reference
            // See: https://www.cambrionix.com/Downloads/API/Cambrionix%20API%20Reference.html#cbrx_notifications
        }

        private class MyNotificationHandler : NotificationHandler
        {
            void NotificationHandler.OnNotificationReceived(string method, object data)
            {
                Console.WriteLine("Notification received '{0}'\n{1}", method, data);
            }
        }

        static private MyNotificationHandler notificationReceiver;

        static int Main()
        {
            notificationReceiver = new MyNotificationHandler();
            api = new CambrionixApi(notificationReceiver);

            if (api.IsConnected)
            {
                SetupMyNotifications();
                GetApiVersion();
                GetDiscoveredHubs();

                //Wait until user exits
                Console.WriteLine("Press any key to exit");
                Console.WriteLine();
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Did not connect to API");
            }

            return 0;
        }
    }
}
