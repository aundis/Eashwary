import { CbrxApi, NotificationPacket, ReplyPacket, ErrorPacket } from './cbrx_api';

interface HubData
{
    serial: string;
    handle: number;
    Hardware: string;
    nrOfPorts: number;

    [index: string]: string | number;
}

type HubContainer = {[key: string]: HubData};

class MyApi extends CbrxApi {

  constructor()
  {
      super();
      this.onError = this.onError.bind(this);
  }

  onApiConnection()
  {
    this.makeRequest("cbrx_apiversion", [true], this.onApiVersionReceived.bind(this), this.onError);
    this.makeRequest("cbrx_discover", ["local"], this.onDiscoverReceived.bind(this), this.onError);
  }

  onApiDisconnection()
  {
    process.exit(0);
  }

  onApiNotification(json: NotificationPacket)
  {
    console.log("Notification received: ", json);
  }

  onApiVersionReceived(json: ReplyPacket)
  {
    const ver = json.result.version;
    console.log("Connected to API version " + ver[0] + "." + ver[1] + "." + ver[2]);
  }

  onDiscoverReceived(json: ReplyPacket)
  {
    if (Array.isArray(json.result))
    {
      console.log("Discovered " + json.result.length + " devices");

      for (const i in json.result)
      {
          const serial = json.result[i];

          ++this.pending;

          const hub: HubData = {
              serial: serial,
              handle: 0,
              nrOfPorts: 0,
              Hardware: "",
          };

          this.hubs[serial] = hub;

          console.log("Requesting " + serial);

          this.makeRequest("cbrx_connection_open", [serial], this.onHubOpened.bind(this, hub), this.onError);
      }
    }
    else
    {
      process.exit(1);
    }
  }

  onHubOpened(hub: HubData, json: ReplyPacket)
  {
    hub.handle = json.result;
    ++this.opened;

    this.makeRequest("cbrx_connection_get", [hub.handle, "nrOfPorts"], this.onHubInfoReceived.bind(this, hub, "nrOfPorts"), this.onError);
    this.makeRequest("cbrx_connection_get", [hub.handle, "Hardware"], this.onHubInfoReceived.bind(this, hub, "Hardware"), this.onError);
  }

  onHubInfoReceived(hub: HubData, key: string, json: ReplyPacket)
  {
    hub[key] = json.result;

    if (hub.Hardware && hub.nrOfPorts)
    {
        console.log(hub.Hardware + " (" + hub.serial + ") has " + hub.nrOfPorts + " ports");
        --this.pending;

        this.makeRequest("cbrx_connection_close", [hub.handle], this.onHubClosed.bind(this, hub), this.onError);
    }
  }

  onHubClosed(hub: HubData, json: ReplyPacket)
  {
    hub.handle = 0;
    --this.opened;

    if (!this.opened)
    {
      this.close();
      process.exit(0);
    }
  }

  onError(json: ErrorPacket)
  {
    console.log("Error received: ", json);
    process.exit(1);
  }

  hubs: HubContainer = {};
  pending = 0;
  opened = 0;
}

let api = new MyApi();

//Program just runs now until told to exit
