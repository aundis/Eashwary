# cbrx_quick_start

Simple example of using Node.JS with a WebSocket to connect to the API and get
information.

## Requirements

Node.JS and either NPM or Yarn.

## Setup

```bash
npm
```

or

```bash
yarn
```

## Running

```bash
npm start
```

or

```bash
yarn start
```
