/**
 * Example way to communicate with the Cambrionix API
 */

import WebSocket from 'ws';

export interface RequestPacket {
  jsonrpc: "2.0";
  /** This will have an incrementally unique ID for each request. */
  id: number | string;
  method: string;
  params: object | any[];
}

export interface NotificationPacket {
  jsonrpc: "2.0";
  /** Will be the name of the notification, such as 'discover-changed' */
  method: string;
  /** Any value, implementation defined. See API docs. */
  params: object | any[];
}

export interface ReplyPacket {
  jsonrpc: "2.0";
  /** id will be the same as the RequestPacket that this is the reply for */
  id: number | string;
  /** Any value, implementation defined. See API docs. */
  result: any;
}

export interface ErrorPacket {
  jsonrpc: "2.0";
  /** id will be the same as the RequestPacket that this is the error for */
  id: number | string;
  error: { code: number, message: string };
}

interface Traffic {
  packet: RequestPacket;
  callback: (error: ReplyPacket) => void;
  callbackError: (error: ErrorPacket) => void;
}

type TrafficContainer = { [key: string]: Traffic };

/**
 * Abstract API access class
 * Other notifications are in reply to makeRequest
 */
export abstract class CbrxApi {
  abstract onApiConnection(): void;
  abstract onApiDisconnection(): void;
  abstract onApiNotification(json: NotificationPacket): void;

  private lastId = 0;
  private websocket: WebSocket;

  private requests: TrafficContainer = {};

  constructor() {
    this.websocket = new WebSocket('ws://localhost:43424', 'jsonrpc');

    this.websocket.on('open', this._onApiConnection.bind(this));
    this.websocket.on('close', this._onApiDisconnection.bind(this));
    this.websocket.on('message', this.onDataReceived.bind(this));
  }

  close() {
    this.websocket.close();
  }

  private onDataReceived(json: string) {
    try {
      const data: ReplyPacket | ErrorPacket | NotificationPacket = JSON.parse(json);
      const id = (data as ReplyPacket | ErrorPacket).id;
      if (id) {
        const request = this.requests[id];

        if ((data as ErrorPacket).error) {
          if (request && request.callbackError) {
            request.callbackError(data as ErrorPacket);
          }
        }
        else {
          if (request && request.callback) {
            request.callback(data as ReplyPacket);
          }
        }
        delete this.requests[id];
      }
      else {
        //Could get a notification here if you enable them on active connection
        //Notifications have no id and can arrive at any time
        if (!(data as any).error) {
          this.onApiNotification(data as NotificationPacket);
        }
      }
    }
    catch (e) {
      console.log("Error handling packet :", e);
    }
  }

  /**
   * Make a request to API and return the result to the provided callback
   * @param method Methodname to call (ie: "cbrx_apiversion")
   * @param params Either an object or array of values
   * @param callback On success
   * @param callbackError On failure
   * @todo Make this a Promise
   */
  makeRequest(method: string, params: object, callback: (error: ReplyPacket) => void, callbackError: (error: ErrorPacket) => void) {
    const packet: RequestPacket = {
      jsonrpc: "2.0",
      id: ++this.lastId,
      method: method,
      params: params,
    };

    this.requests[packet.id] = { packet: packet, callback: callback, callbackError: callbackError };

    this.websocket.send(JSON.stringify(packet));
  }

  private _onApiConnection() {
    this.onApiConnection();
  }

  private _onApiDisconnection() {
    this.requests = {}
    this.onApiDisconnection();
  }
}
