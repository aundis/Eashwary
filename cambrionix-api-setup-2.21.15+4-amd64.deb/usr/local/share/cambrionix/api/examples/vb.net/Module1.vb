Imports System
Imports System.Text
Imports System.Net
Imports System.Net.Sockets
Imports System.Collections.Generic
Imports System.Threading
Imports System.Threading.Tasks
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq

Namespace cbrx_csharp_example
    Public Class CambrionixApi
        Private Const ApiConnectionAddress As String = "localhost"
        Private Const ApiConnectionPort As Integer = 43424
        Private m_socket As Socket
        Private m_connected As Boolean = False
        Private Const BufferSize As Integer = 10240
        Private ReadOnly m_buffer As Byte() = New Byte(10239) {}
        Private ReadOnly m_stringBuilder As StringBuilder = New StringBuilder()

        Public ReadOnly Property IsConnected As Boolean
            Get
                Return m_connected
            End Get
        End Property

        Public Structure Response
            Public m_id As Integer
            Public m_error As Boolean
            Public m_errorInfo As JsonErrorInfo
            Public m_method As String
            Public m_result As Object
            Public m_completeJsonResult As JsonReply
        End Structure

        Private Structure Packet
            Public m_id As Integer
            Friend m_task As TaskCompletionSource(Of Response)
        End Structure

        Private m_nextID As Integer = 0
        Private ReadOnly m_pending As Dictionary(Of Integer, Packet) = New Dictionary(Of Integer, Packet)()

        Public Sub New()
            StartClient()
        End Sub

        Protected Overrides Sub Finalize()
            StopClient()
        End Sub

        Private Sub StartClient()
            Try
                Dim ipHostInfo As IPHostEntry = Dns.GetHostEntry(ApiConnectionAddress)
                Dim ipAddress As IPAddress = ipHostInfo.AddressList(1)
                Dim remoteEP As IPEndPoint = New IPEndPoint(ipAddress, ApiConnectionPort)
                m_socket = New Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp)
                m_socket.Connect(remoteEP)

                If m_socket.Connected Then
                    m_connected = True
                    Receive()
                End If

            Catch e As Exception
                Console.WriteLine(e.ToString())
            End Try
        End Sub

        Private Sub StopClient()
            m_socket.Close()
        End Sub

        Private Sub Receive()
            Try
                m_socket.BeginReceive(m_buffer, 0, BufferSize, 0, New AsyncCallback(AddressOf ReceiveCallback), Me)
            Catch e As Exception
                Console.WriteLine(e.ToString())
            End Try
        End Sub

        Private Sub ReceiveCallback(ByVal ar As IAsyncResult)
            Try
                Dim bytesRead As Integer = m_socket.EndReceive(ar)

                If bytesRead > 0 Then
                    m_stringBuilder.Append(Encoding.ASCII.GetString(m_buffer, 0, bytesRead))

                    If ar.IsCompleted Then
                        Dim response As String = m_stringBuilder.ToString()
                        m_stringBuilder.Clear()
                        OnJsonReceived(response)
                    End If
                End If

                Receive()
            Catch e As Exception
                Console.WriteLine(e.ToString())
            End Try
        End Sub

        Private Sub Send(ByVal data As String)
            Dim byteData As Byte() = Encoding.ASCII.GetBytes(data)
            m_socket.Send(byteData)
        End Sub

        Public Structure JsonErrorInfo
            Public Property code As Integer
            Public Property message As String
        End Structure

        Public Structure JsonReply
            Public Property id As Integer
            Public Property jsonrpc As String
            Public Property method As String
            Public Property result As Object
            Public Property [error] As JsonErrorInfo
        End Structure

        Private Sub OnJsonReceived(ByVal json As String)
            Dim result As JsonReply = JsonConvert.DeserializeObject(Of JsonReply)(json)

            If result.id = 0 Then
            Else

                If m_pending.ContainsKey(result.id) Then
                    Dim pending As Packet = m_pending(result.id)
                    Dim reply As Response = New Response With {
                        .m_completeJsonResult = result,
                        .m_result = result.result,
                        .m_id = result.id,
                        .m_errorInfo = result.[error],
                        .m_error = result.[error].code <> 0
                    }

                    If reply.m_error Then
                        Console.[Error].WriteLine("Error received from API : {0} {1}", result.[error].code, result.[error].message)
                    End If

                    pending.m_task.SetResult(reply)
                    m_pending.Remove(result.id)
                End If
            End If
        End Sub

        Public Function MakeRequest(ByVal method As String, ByVal Optional parameters As Object = Nothing) As TaskCompletionSource(Of Response)
            Try
                Dim packet As Packet
                packet.m_id = Interlocked.Increment(m_nextID)
                packet.m_task = New TaskCompletionSource(Of Response)()
                Dim json As Dictionary(Of String, Object) = New Dictionary(Of String, Object)()
                json("id") = packet.m_id
                json("jsonrpc") = "2.0"
                json("method") = method

                If parameters IsNot Nothing Then
                    json("params") = parameters
                End If

                Dim serialisedJson = JsonConvert.SerializeObject(json)
                Send(serialisedJson)
                m_pending(packet.m_id) = packet
                Return packet.m_task
            Catch e As Exception
                Console.WriteLine(e.ToString())
            End Try

            Return Nothing
        End Function
    End Class

    Class Program
        Private Shared api As CambrionixApi
        Private Shared pendingActions As Integer = 0

        Private Shared Async Sub GetApiVersion()
            Interlocked.Increment(pendingActions)
            Dim future = api.MakeRequest("cbrx_apiversion")
            Dim result = Await future.Task

            If result.m_error Then
                Console.WriteLine("Could not get API Version: " & result.m_error.ToString())
            ElseIf TypeOf result.m_result Is JArray Then
                Dim version As JArray = TryCast(result.m_result, JArray)
                Console.WriteLine("API Version: " & String.Join(".", version))
            End If

            Interlocked.Decrement(pendingActions)
        End Sub

        Private Shared Async Sub GetDiscoveredHubs()
            Interlocked.Increment(pendingActions)

            Try
                Dim future = api.MakeRequest("cbrx_discover", {"local"})
                Dim resultDiscover = Await future.Task

                If Not resultDiscover.m_error Then

                    If TypeOf resultDiscover.m_result Is JArray Then
                        Dim result As JArray = TryCast(resultDiscover.m_result, JArray)
                        Console.WriteLine("Found the following Cambrionix hubs: " & String.Join(", ", result))

                        For Each entry In result
                            Dim hubSerialNumber As String = entry.Value(Of String)()
                            GetHubInformation(hubSerialNumber)
                        Next
                    End If
                End If

            Catch e As Exception
                Console.WriteLine(e.ToString())
            End Try

            Interlocked.Decrement(pendingActions)
        End Sub

        Private Shared Async Sub GetHubInformation(ByVal hubSerialNumber As String)
            Interlocked.Increment(pendingActions)

            Try
                Dim futureOpen = api.MakeRequest("cbrx_connection_open", {hubSerialNumber})
                Dim resultOpen = Await futureOpen.Task

                If Not resultOpen.m_error Then

                    If TypeOf resultOpen.m_result Is Long Then
                        Dim handle As Long = CLng(resultOpen.m_result)
                        Dim futureGetPortsInfo = api.MakeRequest("cbrx_connection_get", New Object() {handle, "PortsInfo"})
                        Dim resultGetPortsInfo = Await futureGetPortsInfo.Task

                        If Not resultGetPortsInfo.m_error Then

                            If TypeOf resultGetPortsInfo.m_result Is JObject Then
                                Dim discovery As JObject = TryCast(resultGetPortsInfo.m_result, JObject)
                                Dim numberOfPorts As Integer = discovery.Count
                                Console.WriteLine("The hub {0} has {1} ports", hubSerialNumber, numberOfPorts)

                                For Each entry In discovery
                                    Dim values = entry.Value
                                    Dim attached As Boolean = values.Value(Of String)("Flags").Contains("A")

                                    If attached Then
                                        Dim portNumber As Integer = values.Value(Of Integer)("Port")
                                        Dim manufacturer = values.Value(Of String)("Manufacturer")
                                        Dim description = values.Value(Of String)("Description")
                                        Dim currentMA = values.Value(Of Integer)("Current_mA")
                                        Console.WriteLine("{0}: Port {1} has a {2} {3} which is drawing {4} milliamps", hubSerialNumber, portNumber, manufacturer, description, currentMA)
                                    End If
                                Next
                            End If
                        End If
                    End If
                Else
                    Console.WriteLine("Could not connect to the hub : {0} {1} ", resultOpen.m_errorInfo.code, resultOpen.m_errorInfo.message)
                End If

            Catch e As Exception
                Console.WriteLine(e.ToString())
            End Try

            Interlocked.Decrement(pendingActions)
        End Sub

        Public Shared Function Main() As Integer
            api = New CambrionixApi()

            If api.IsConnected Then
                GetApiVersion()
                GetDiscoveredHubs()

                While pendingActions > 0
                    Thread.Sleep(100)
                End While
            End If

            Return 0
        End Function
    End Class
End Namespace

' The above was automatically generated from the C# example, so may not represent best practices in VB.NET

Module Module1

    Sub Main()
        cbrx_csharp_example.Program.Main()
    End Sub

End Module
